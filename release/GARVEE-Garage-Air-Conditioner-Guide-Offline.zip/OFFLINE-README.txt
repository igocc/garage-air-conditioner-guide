GARVEE Garage Air Conditioner Guide - Offline Edition

Open garage-air-conditioner-guide-offline.html in a modern browser.
The guide, images, fonts, planner, filters, and interactive modules work without a network connection.
Links to GARVEE product pages and external research sources require internet access.
The installation-service module is a non-submitting concept demonstration.

Generated from the repository with: npm run build:offline